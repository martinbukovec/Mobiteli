import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useTable, useFilters, useSortBy } from 'react-table';
import './App.css';

const DataTable = ({ columns, data, fetchData }) => {
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        rows,
        prepareRow,
    } = useTable(
        {
            columns,
            data,
        },
        useFilters, // Dodali smo upotrebu filtera
        useSortBy // Dodali smo upotrebu sortiranja
    );

    const exportFilteredData = (format) => {
        const filteredData = rows.map((row) =>
            row.cells.reduce((acc, cell, index) => {
                acc[columns[index].Header] = cell.value;
                return acc;
            }, {})
        );

        if (format === 'csv') {
            // Generiranje CSV-a s filtriranim podacima
            const csvContent =
                'data:text/csv;charset=utf-8,' +
                columns.map((col) => col.Header).join(',') +
                '\n' +
                filteredData.map((row) => columns.map((col) => row[col.Header]).join(',')).join('\n');

            const encodedUri = encodeURI(csvContent);
            const link = document.createElement('a');
            link.setAttribute('href', encodedUri);
            link.setAttribute('download', 'Mobiteli.csv');
            document.body.appendChild(link);
            link.click();
        } else if (format === 'json') {
            const jsonContent = JSON.stringify(filteredData, null, 2);

            const encodedUri = encodeURI('data:text/json;charset=utf-8,' + jsonContent);
            const link = document.createElement('a');
            link.setAttribute('href', encodedUri);
            link.setAttribute('download', 'Mobiteli.json');
            document.body.appendChild(link);
            link.click();
        }
    };

    return (

        <div>
            <h1>
                Mobiteli
                <button id="download-buttons" onClick={() => exportFilteredData('csv')}>Preuzmi CSV</button>
                <button id="download-buttons" onClick={() => exportFilteredData('json')}>Preuzmi JSON</button>
            </h1>
            <table {...getTableProps()}>
                <thead>
                {headerGroups.map((headerGroup) => (
                    <tr {...headerGroup.getHeaderGroupProps()}>
                        {headerGroup.headers.map((column) => (
                            <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                                {column.render('Header')}
                                <span>
                                        {column.isSorted ? (column.isSortedDesc ? ' 🔽' : ' 🔼') : ''}
                                    </span>
                                {/* Dodali smo input polje za filtriranje */}
                                <div>{column.canFilter ? column.render('Filter') : null}</div>
                            </th>
                        ))}
                    </tr>
                ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                {rows.map((row) => {
                    prepareRow(row);
                    return (
                        <tr {...row.getRowProps()}>
                            {row.cells.map((cell) => (
                                <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                            ))}
                        </tr>
                    );
                })}
                </tbody>
            </table>
        </div>
    );
};

const App = () => {
    const [data, setData] = useState([]);

    const fetchData = async () => {
        try {
            const response = await axios.get('http://localhost:8080/data');
            const rows = response.data.split('\n').map((row) => row.split(','));
            const headers = rows[0];
            const formattedData = rows.slice(1).map((row) => {
                const formattedRow = {};
                row.forEach((cell, index) => {
                    formattedRow[headers[index]] = cell;
                });
                return formattedRow;
            });
            setData(formattedData);
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    const columns = data.length > 0 ? Object.keys(data[0]).map((header) => ({ Header: header, accessor: header, Filter: DefaultColumnFilter })) : [];

    return (
        <div>
            <DataTable columns={columns} data={data} fetchData={fetchData} />
        </div>
    );
};

// Dodali smo defaultni filter za stupce
const DefaultColumnFilter = ({ column: { filterValue, setFilter } }) => {
    return (
        <input
            value={filterValue || ''}
            onChange={(e) => setFilter(e.target.value)}
            placeholder={`Filter...`}
        />
    );
};

export default App;
