package com.example.mobiteli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobiteliApplicationTests {

    @Test
    void contextLoads() {
    }

}
