package com.example.mobiteli.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class service {

    @PersistenceContext
    private EntityManager entityManager;

    public List<Object[]> executeCustomQuery() {
        String sqlQuery = "SELECT model.proizvodac, model.model, model.os, model.ekran, model.brojkamera, model.kamera, model.procesor, model.baterija, model.brzinapunjenja, model.vodootpornost, model.maxsvjetlina, model.stopaosvjezavanja, model.pocetnacijena, pohrana.radnamemorija, pohrana.pohrana, boja.nazivboje " +
                "FROM mobitel " +
                "JOIN model ON mobitel.idmodela = model.idmodela " +
                "JOIN pohrana ON mobitel.idpohrane = pohrana.idpohrane " +
                "JOIN boja ON mobitel.idboje = boja.idboje";

        Query query = entityManager.createNativeQuery(sqlQuery);
        return query.getResultList();
    }
}
