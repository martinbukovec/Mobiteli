package com.example.mobiteli.entity;
import jakarta.persistence.*;

@Entity
public class mobitel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idmobitela;

    @ManyToOne
    @JoinColumn(name = "idmodela")
    private model model;

    @ManyToOne
    @JoinColumn(name = "idpohrane")
    private pohrana pohrana;

    @ManyToOne
    @JoinColumn(name = "idboje")
    private boja boja;

    // Getters and setters
    public Long getIdmobitela() {
        return idmobitela;
    }

    public void setIdmobitela(Long idmobitela) {
        this.idmobitela = idmobitela;
    }

    public model getModel() {
        return model;
    }

    public void setModel(model model) {
        this.model = model;
    }

    public pohrana getPohrana() {
        return pohrana;
    }

    public void setPohrana(pohrana pohrana) {
        this.pohrana = pohrana;
    }

    public boja getBoja() {
        return boja;
    }

    public void setBoja(boja boja) {
        this.boja = boja;
    }
}
