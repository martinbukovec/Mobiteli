package com.example.mobiteli.repository;

import com.example.mobiteli.entity.pohrana;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PohranaRepository extends JpaRepository<pohrana, Long> {
    // Dodatne metode za prilagodbu upita za PohranaEntity
}
