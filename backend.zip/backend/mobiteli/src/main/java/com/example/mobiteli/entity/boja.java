package com.example.mobiteli.entity;

import jakarta.persistence.*;

@Entity
public class boja {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idboje;

    private String nazivboje;

    // Getters and setters
    public Long getIdboje() {
        return idboje;
    }

    public void setIdboje(Long idboje) {
        this.idboje = idboje;
    }

    public String getNazivboje() {
        return nazivboje;
    }

    public void setNazivboje(String nazivboje) {
        this.nazivboje = nazivboje;
    }
}
