package com.example.mobiteli.controllers;

import com.example.mobiteli.service.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletResponse; // Dodajte ovo

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/data")
public class controller {

    @Autowired
    private service customQueryService;

    @GetMapping
    public void executeCustomQuery(HttpServletResponse response) throws IOException {
        List<Object[]> result = customQueryService.executeCustomQuery();

        // Postavljanje zaglavlja
        response.setHeader("Content-Type", "application/json");
        response.setHeader("Access-Control-Allow-Origin", "*");

        // Stvaranje CSV stringa za zaglavlje
        String header = "Proizvodac,Model,OS,Ekran,Broj kamera,Kvaliteta kamere,Procesor,Kapacitet baterije,Brzina punjenja,Vodootpornost,Maksimalna svjetlina,Stopa osvjezavanja ekrana,Pocetna cijena,Radna memorija,Pohrana,Boja\n";

        // Stvaranje CSV stringa za podatke
        StringBuilder csvData = new StringBuilder(header);
        for (Object[] row : result) {
            for (Object value : row) {
                csvData.append(value).append(",");
            }
            csvData.deleteCharAt(csvData.length() - 1); // Ukloni zadnji zarez
            csvData.append("\n");
        }

        // Slanje podataka kao odgovor
        response.getWriter().write(csvData.toString());
    }
}
