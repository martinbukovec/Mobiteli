package com.example.mobiteli.repository;


import com.example.mobiteli.entity.mobitel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MobitelRepository extends JpaRepository<mobitel, Long> {
    // Dodatne metode za prilagodbu upita za MobitelEntity
}
