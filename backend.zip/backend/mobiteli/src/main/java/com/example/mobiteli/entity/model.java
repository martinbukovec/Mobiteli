package com.example.mobiteli.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class model {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idmodela;

    private String proizvodac;
    private String model;
    private String os;
    private double ekran;
    private int brojkamera;
    private int kamera;
    private String procesor;
    private int baterija;
    private int brzinapunjenja;
    private String vodootpornost;
    private int maxsvjetlina;
    private int stopaosvjezavanja;
    private int pocetnacijena;

    // Dodajte gettere i settere za sve atribute

    public Long getIdmodela() {
        return idmodela;
    }

    public void setIdmodela(Long idmodela) {
        this.idmodela = idmodela;
    }

    public String getProizvodac() {
        return proizvodac;
    }

    public void setProizvodac(String proizvodac) {
        this.proizvodac = proizvodac;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public double getEkran() {
        return ekran;
    }

    public void setEkran(double ekran) {
        this.ekran = ekran;
    }

    public int getBrojkamera() {
        return brojkamera;
    }

    public void setBrojkamera(int brojkamera) {
        this.brojkamera = brojkamera;
    }

    public int getKamera() {
        return kamera;
    }

    public void setKamera(int kamera) {
        this.kamera = kamera;
    }

    public String getProcesor() {
        return procesor;
    }

    public void setProcesor(String procesor) {
        this.procesor = procesor;
    }

    public int getBaterija() {
        return baterija;
    }

    public void setBaterija(int baterija) {
        this.baterija = baterija;
    }

    public int getBrzinapunjenja() {
        return brzinapunjenja;
    }

    public void setBrzinapunjenja(int brzinapunjenja) {
        this.brzinapunjenja = brzinapunjenja;
    }

    public String getVodootpornost() {
        return vodootpornost;
    }

    public void setVodootpornost(String vodootpornost) {
        this.vodootpornost = vodootpornost;
    }

    public int getMaxsvjetlina() {
        return maxsvjetlina;
    }

    public void setMaxsvjetlina(int maxsvjetlina) {
        this.maxsvjetlina = maxsvjetlina;
    }

    public int getStopaosvjezavanja() {
        return stopaosvjezavanja;
    }

    public void setStopaosvjezavanja(int stopaosvjezavanja) {
        this.stopaosvjezavanja = stopaosvjezavanja;
    }

    public int getPocetnacijena() {
        return pocetnacijena;
    }

    public void setPocetnacijena(int pocetnacijena) {
        this.pocetnacijena = pocetnacijena;
    }
}
