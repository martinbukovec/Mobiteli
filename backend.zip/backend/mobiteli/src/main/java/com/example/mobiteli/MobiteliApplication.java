package com.example.mobiteli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobiteliApplication {

    public static void main(String[] args) {
        SpringApplication.run(MobiteliApplication.class, args);
    }

}
