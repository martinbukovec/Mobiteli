package com.example.mobiteli.repository;


import com.example.mobiteli.entity.model;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ModelRepository extends JpaRepository<model, Long> {
    // Dodatne metode za prilagodbu upita za ModelEntity

    List<model> findByProizvodac(String proizvodac);
    // Dodajte ostale metode prema potrebi
}





