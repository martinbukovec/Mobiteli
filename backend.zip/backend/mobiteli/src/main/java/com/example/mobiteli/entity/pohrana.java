package com.example.mobiteli.entity;

import jakarta.persistence.*;

@Entity
public class pohrana {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idpohrane;

    private int radnamemorija;
    private int pohrana;

    // Getters and setters
    public Long getIdpohrane() {
        return idpohrane;
    }

    public void setIdpohrane(Long idpohrane) {
        this.idpohrane = idpohrane;
    }

    public int getRadnamemorija() {
        return radnamemorija;
    }

    public void setRadnamemorija(int radnamemorija) {
        this.radnamemorija = radnamemorija;
    }

    public int getPohrana() {
        return pohrana;
    }

    public void setPohrana(int pohrana) {
        this.pohrana = pohrana;
    }
}
