package com.example.mobiteli.repository;

import com.example.mobiteli.entity.boja;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BojaRepository extends JpaRepository<boja, Long> {
    // Dodatne metode za prilagodbu upita za BojaEntity
}
